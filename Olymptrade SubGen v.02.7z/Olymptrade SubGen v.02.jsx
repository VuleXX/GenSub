function buildUI(thisObj) {
    var isScript = !(thisObj instanceof Panel);
    var win = isScript
        ? new Window("dialog", "Olymptrade Subtitle Generator v0.2")
        : thisObj;

    win.orientation = "column";
    win.alignChildren = ["fill", "top"];
    win.margins = 15;

    // --- Логотип + версия в одной строке ---
    var logoAndVersionGroup = win.add("group");
    logoAndVersionGroup.orientation = "row";
    logoAndVersionGroup.alignChildren = ["fill", "center"];
    logoAndVersionGroup.alignment = "fill";

    // Логотип
    var scriptFile = new File($.fileName);
    var scriptFolder = scriptFile.parent;
    var logoFile = File(scriptFolder.fsName + "/logo.png");
    if (logoFile.exists) {
        var logoImage = logoAndVersionGroup.add("image", undefined, logoFile);
        logoImage.preferredSize = [340, 64];
        logoImage.helpTip = "Логотип плагина Olymptrade Subtitle Generator";
    } else {
        var logoText = logoAndVersionGroup.add("statictext", undefined, "Логотип не найден");
        logoText.helpTip = "Логотип не найден. Поместите logo.png рядом со скриптом.";
    }

    // Spacer (растяжка)
    var logoSpacer = logoAndVersionGroup.add("statictext", undefined, "");
    logoSpacer.alignment = ["fill", "center"];

    // Версия справа
    var versionLabel = logoAndVersionGroup.add("statictext", undefined, "version 0.2");
    versionLabel.helpTip = "Версия скрипта Olymptrade Subtitle Generator";
    versionLabel.alignment = "right";

    // --- Имя слоя и префикс ---
    var nameGroup = win.add("group");
    nameGroup.orientation = "row";
    nameGroup.alignChildren = ["fill", "center"];
    var nameLabel = nameGroup.add("statictext", undefined, "Имя слоя:");
    nameLabel.helpTip = "Введите имя для создаваемого текстового слоя";

    var prefixDropdown = nameGroup.add(
        "dropdownlist",
        undefined,
        ["—", "EN", "ID", "AR", "PT", "UD", "UR", "BN", "ES", "TH", "MS", "VI", "RU"]
    );
    prefixDropdown.preferredSize.width = 120;
    prefixDropdown.selection = 0;
    prefixDropdown.helpTip = "Выберите префикс для имени слоя. Например, 'EN' для английского, 'AR' для арабского и т.д.";

    var nameInput = nameGroup.add("edittext", undefined, "");
    nameInput.preferredSize.width = 250;
    nameInput.helpTip = "Введите уникальное имя для текстового слоя. Префикс будет добавлен автоматически.";

    // --- Группа для поля маркеров и кнопок ---
    var markerAndButtonsGroup = win.add("group");
    markerAndButtonsGroup.orientation = "column";
    markerAndButtonsGroup.alignChildren = ["fill", "top"];

    // --- Поле для текста маркеров ---
    var inputText = markerAndButtonsGroup.add(
        "edittext",
        undefined,
        "Поле для текста маркеров, \nразделяйте текст переносом строки",
        { multiline: true, scrolling: true }
    );
    inputText.preferredSize = [400, 200];
    inputText.active = true;
    inputText.helpTip = "Введите текст для каждого маркера на новой строке. Каждый маркер будет создан с этим текстом.";

    // --- Группа для всех кнопок справа ---
    var allBtnGroup = markerAndButtonsGroup.add("group");
    allBtnGroup.orientation = "row";
    allBtnGroup.alignment = "right";

    var updateFontsBtn = allBtnGroup.add("button", undefined, "Обновить шрифты");
    updateFontsBtn.helpTip = "Обновить шрифты всех текстовых слоёв в активной композиции: для AR — NotoSansArabic-Bold, для остальных — Nacelle-Bold.";

    var importBtn = allBtnGroup.add("button", undefined, "Import .CSV");
    importBtn.helpTip = "Импортировать маркеры из CSV-файла. Для пакетного создания слоёв по данным из таблицы.";

    var okBtn = allBtnGroup.add("button", undefined, "OK");
    okBtn.helpTip = "Создать текстовый слой с маркерами на основе введённого текста и имени слоя.";

    var cancelBtn = allBtnGroup.add("button", undefined, "Отмена");
    cancelBtn.helpTip = "Закрыть окно плагина.";

    // --- Обработчики кнопок ---
    updateFontsBtn.onClick = function () {
        var comp = app.project.activeItem;
        if (!(comp && comp instanceof CompItem)) {
            alert("Пожалуйста, откройте композицию.");
            return;
        }
        app.beginUndoGroup("Обновление шрифтов");
        for (var i = 1; i <= comp.numLayers; i++) {
            var layer = comp.layer(i);
            if (layer instanceof TextLayer) {
                var prefix = layer.name.split("_")[0];
                var textProp = layer.property("Source Text");
                var textDoc = textProp.value;
                if (prefix === "AR") {
                    textDoc.font = "NotoSansArabic-Bold";
                } else {
                    textDoc.font = "Nacelle-Bold";
                }
                textProp.setValue(textDoc);
            }
        }
        app.endUndoGroup();
        alert("Шрифты обновлены для всех подходящих слоёв.");
    };

    importBtn.onClick = function () {
        var csvFile = File.openDialog("Выберите CSV файл", "*.csv");
        if (csvFile && csvFile.open("r")) {
            var csvText = csvFile.read();
            csvFile.close();
            parseCSVAndCreateLayers(csvText);
            alert("Импорт из CSV завершён!");
        } else {
            alert("Не удалось открыть файл.");
        }
    };

    okBtn.onClick = function () {
        var comp = app.project.activeItem;
        if (!(comp && comp instanceof CompItem)) {
            alert("Пожалуйста, откройте композицию.");
            return;
        }
        var textValue = inputText.text;
        var userLayerName = nameInput.text.trim();
        var prefixIndex = prefixDropdown.selection.index;
        if (!userLayerName) {
            alert("Введите имя слоя.");
            return;
        }
        if (!textValue) {
            alert("Введите текст для маркеров.");
            return;
        }
        app.beginUndoGroup("Создание текстового слоя");
        var prefix = prefixDropdown.selection.text;
        var fullLayerName = prefixIndex === 0 ? userLayerName : prefix + "_" + userLayerName;
        createTextLayerWithMarkers(comp, textValue, fullLayerName);
        app.endUndoGroup();
        alert("Текстовый слой успешно создан.");
    };

    cancelBtn.onClick = function () {
        if (win instanceof Window) win.close();
        else win.visible = false;
    };

    // Поддержка изменения размера для панели
    if (!isScript) {
        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };
        win.layout.layout(true);
    }

    // --- Вспомогательные функции ---
    function parseCSVAndCreateLayers(csvText) {
        app.beginUndoGroup("Импорт маркеров из CSV");
        var lines = csvText.split(/\r\n|\r|\n/), columns = [];
        function parseCsvLine(line) {
            var result = [], inQuote = false, cell = "";
            for (var i = 0; i < line.length; i++) {
                var ch = line[i];
                if (ch === '"') {
                    if (inQuote && line[i + 1] === '"') { cell += '"'; i++; }
                    else inQuote = !inQuote;
                } else if (ch === ',' && !inQuote) {
                    result.push(cell); cell = "";
                } else cell += ch;
            }
            result.push(cell);
            return result;
        }
        var maxCols = 0;
        for (var i = 0; i < lines.length; i++) {
            var cells = parseCsvLine(lines[i]);
            maxCols = Math.max(maxCols, cells.length);
        }
        for (var c = 0; c < maxCols; c++) columns[c] = [];
        for (var i = 0; i < lines.length; i++) {
            var cells = parseCsvLine(lines[i]);
            for (var c = 0; c < maxCols; c++) {
                columns[c].push(cells[c] || "");
            }
        }
        var comp30s = findCompByName("ST_30s") || app.project.items.addComp("ST_30s", 1920, 450, 1, 30, 25);
        var comp15s = findCompByName("ST_15s") || app.project.items.addComp("ST_15s", 1920, 450, 1, 15, 25);
        for (var c = 0; c < columns.length; c++) {
            var col = columns[c], baseName = col[0];
            if (!baseName) continue;
            var blockName = baseName, blockLines = [];
            for (var i = 1; i < col.length; i++) {
                var cell = col[i];
                if (cell === "30s" || cell === "15s") {
                    if (blockLines.length) {
                        if (blockName.includes("30s")) createTextLayerWithMarkers(comp30s, blockLines.join("\n"), blockName);
                        else if (blockName.includes("15s")) createTextLayerWithMarkers(comp15s, blockLines.join("\n"), blockName);
                        else {
                            createTextLayerWithMarkers(comp30s, blockLines.join("\n"), blockName);
                            createTextLayerWithMarkers(comp15s, blockLines.join("\n"), blockName);
                        }
                        blockLines = [];
                    }
                    blockName = baseName + "_ST_" + cell;
                } else if (cell) {
                    blockLines.push(cell);
                }
            }
            if (blockLines.length) {
                if (blockName.includes("30s")) createTextLayerWithMarkers(comp30s, blockLines.join("\n"), blockName);
                else if (blockName.includes("15s")) createTextLayerWithMarkers(comp15s, blockLines.join("\n"), blockName);
                else {
                    createTextLayerWithMarkers(comp30s, blockLines.join("\n"), blockName);
                    createTextLayerWithMarkers(comp15s, blockLines.join("\n"), blockName);
                }
            }
        }
        app.endUndoGroup();
    }

    function findCompByName(name) {
        for (var i = 1; i <= app.project.numItems; i++) {
            var item = app.project.item(i);
            if (item instanceof CompItem && item.name === name) return item;
        }
        return null;
    }

    function createTextLayerWithMarkers(comp, text, userLayerName) {
        var lines = text.split(/\r\n|\r|\n/).map(function(l){ return l.trim(); }).filter(Boolean);
        if (!lines.length) return;
        var newTextLayer = comp.layers.addText(lines.join("\r"));
        newTextLayer.name = userLayerName;
        newTextLayer.inPoint = 0;
        newTextLayer.outPoint = Math.max(comp.duration, lines.length);
        var markerProp = newTextLayer.property("Marker");
        for (var i = markerProp.numKeys; i >= 1; i--) markerProp.removeKey(i);
        lines.forEach(function(line, idx) {
            var t = newTextLayer.inPoint + idx;
            if (t > newTextLayer.outPoint) t = newTextLayer.outPoint;
            markerProp.setValueAtTime(t, new MarkerValue(line));
        });
        var textProp = newTextLayer.property("Source Text");
        var doc = textProp.value;
        doc.justification = ParagraphJustification.CENTER_JUSTIFY;
        textProp.setValue(doc);
        // Компактное выражение только для текста из маркера:
        var sourceExpr =
            "n = marker.numKeys > 0 ? marker.nearestKey(time).index : 0;\n" +
            "n = n > 1 && marker.key(n).time > time ? n - 1 : n;\n" +
            "n > 0 ? marker.key(n).comment : \"Olymptrade subtitle v0.01\";";
        newTextLayer.property("Source Text").expression = sourceExpr;
        var opacityExpr =
            "(thisLayer.name.slice(0,2).toUpperCase()==comp(\"_ProjectControls\").layer(\"CONTROL\").text.sourceText.match(/^[^\\r\\n]+/gm)[1].split(\" | \")[0].toUpperCase())?value:0;";
        newTextLayer.property("Opacity").expression = opacityExpr;
    }

    return win;
}

// Инициализация
var myWindow = buildUI(this);
if (myWindow instanceof Window) {
    myWindow.center();
    myWindow.show();
}
